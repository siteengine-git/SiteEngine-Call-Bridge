<?php
/**
 * Twilio recording status callback controller.
 *
 * Fires once a recording is finalized. We store the RecordingUrl and
 * duration on the matching call_log row.
 *
 * Recording URL stored as-is (Twilio-hosted). For long-term archival or
 * compliance copy, we'd add a separate job to download and re-host —
 * out of scope for now.
 *
 * @package SiteEngine\CallBridge\Webhook
 */

declare(strict_types=1);

namespace SiteEngine\CallBridge\Webhook;

use SiteEngine\CallBridge\DB\CallLogRepository;
use SiteEngine\CallBridge\Support\Logger;
use SiteEngine\CallBridge\Support\WebhookEvents;
use SiteEngine\CallBridge\Twilio\SignatureValidator;
use WP_REST_Request;

defined('ABSPATH') || exit;

final class TwilioRecordingController
{
    public function handle(WP_REST_Request $request): void
    {
        WebhookEvents::record(WebhookEvents::RECORDING_HIT);

        if (!SignatureValidator::validateCurrentRequest()) {
            WebhookEvents::record(WebhookEvents::RECORDING_SIGNATURE_FAIL);
            status_header(403);
            echo '';
            exit;
        }

        // Twilio sends recording callbacks with the parent CallSid in
        // CallSid (the inbound leg), and recording details in RecordingSid,
        // RecordingUrl, RecordingDuration.
        $post = wp_unslash($_POST);
        $callSid           = (string) ($post['CallSid'] ?? '');
        $recordingSid      = (string) ($post['RecordingSid'] ?? '');
        $recordingUrl      = (string) ($post['RecordingUrl'] ?? '');
        $recordingDuration = max(0, (int) ($post['RecordingDuration'] ?? 0));
        // Legacy completed callbacks may omit RecordingStatus; incomplete/absent
        // events must never erase an already persisted completed marker.
        $recordingStatus = (string) ($post['RecordingStatus'] ?? 'completed');

        if ($callSid === '' || $recordingSid === '') {
            Logger::warn('recording_missing_params', compact('callSid', 'recordingSid'));
            $this->emitEmpty();
            return;
        }

        if ($recordingStatus !== 'completed' || $recordingUrl === '') {
            $this->emitEmpty();
            return;
        }

        try {
            $callRepo = new CallLogRepository();
            for ($attempt = 0; $attempt < 3; $attempt++) {
                $existing = $callRepo->findByCallSid($callSid, true);
                if ($existing === null) {
                    Logger::warn('recording_call_not_found', ['call_sid' => $callSid]);
                    WebhookEvents::record(WebhookEvents::RECORDING_UNMATCHED, $callSid);
                    $this->emitEmpty();
                    return;
                }
                if (!empty($existing['recording_sid']) && !empty($existing['recording_url'])) {
                    $this->emitEmpty();
                    return;
                }
                $expected = array_intersect_key($existing, array_flip(['recording_sid','recording_url','recording_duration_sec']));
                if ($callRepo->updateIfCurrent((int) $existing['id'], [
                    'recording_sid'          => $recordingSid,
                    'recording_url'          => $recordingUrl,
                    'recording_duration_sec' => $recordingDuration,
                ], $expected, true)) {
                    $this->emitEmpty();
                    return;
                }
            }
            $winner = $callRepo->findByCallSid($callSid, true);
            if (!empty($winner['recording_sid']) && !empty($winner['recording_url'])) {
                $this->emitEmpty();
                return;
            }
        } catch (\Throwable $e) {
            Logger::error('recording_update_failed');
        }
        // Signals uncertainty, without claiming the provider will retry.
        status_header(503);
        header('Content-Type: text/plain; charset=utf-8');
        echo 'Recording persistence unavailable';
        exit;
    }

    private function emitEmpty(): void
    {
        status_header(200);
        header('Content-Type: text/xml; charset=utf-8');
        echo '<?xml version="1.0" encoding="UTF-8"?><Response/>';
        exit;
    }
}
